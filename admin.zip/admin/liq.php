<?php
session_start();
if(!isset($_SESSION['adminValid'])){
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>Liquidate Dashboard</title>
    <meta name="theme-color" content="#fd961a">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="http://boscoempresarios2018.com/images/favicon.png">

    <!-- Template CSS Files -->
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/magnific-popup.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/select2.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/style.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/skins/orange.css">

    <!-- Live Style Switcher - demo only -->
    <link rel="alternate stylesheet" type="text/css" title="orange" href="css/skins/orange.css" /> 

    <!-- Template JS Files -->
    <script src="js/modernizr.js"></script>

</head>

<body>
    <!-- Wrapper Starts -->
    <div class="wrapper">
        <!-- Header Starts -->
        <header class="header">
            <div class="container">
                <div class="row">
                    <!-- Logo Starts -->
                    <div class="main-logo col-xs-12 col-md-3 col-md-2 col-lg-2 hidden-xs">
                        <a href="index.php">
                            <img id="logo" class="img-responsive" src="http://boscoempresarios2018.com/images/logo-dark.png" alt="logo">
                        </a>
                    </div>
                    <!-- Logo Ends -->
                    <!-- Statistics Starts -->
                    <div class="col-md-7 col-lg-7">
                        <marquee><ul class="unstyled bitcoin-stats text-center">

                            <?php
                                $host="localhost";
                                $user="boscofes_bemp";
                                $pass="FatherJohnBoscoBoscoFest2018";
                                $db="boscofes_bemp";

                                 $con=mysqli_connect($host,$user,$pass,$db);
                                 if (mysqli_connect_errno())
                                 {
                                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                 }                                 
                                 $sql= "SELECT * FROM share_prices";
                                 $result=mysqli_query($con,$sql);
                                 while($row = mysqli_fetch_array($result)){
                                    if($row['curr_price']>$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-up\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else if($row['curr_price']<$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-down\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-no-change\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                }
                                  

                            ?>
                        </ul></marquee>
                    </div>
                    <!-- Statistics Ends -->
                    <!-- User Sign In/Sign Up Starts -->
                    <div class="col-md-3 col-lg-3">
                        <ul class="unstyled user">
                            <li class="sign-in"><a href="http://boscoempresarios2018.com/shares.php" class="btn btn-primary" target="_blank">Stock Exchange</a></li>
                        </ul>
                    </div>
                    <!-- User Sign In/Sign Up Ends -->
                </div>
            </div>
        </header>
        <!-- Header Ends -->
        <!-- Banner Area Starts -->
        <section class="banner-area">
            <div class="banner-overlay">
                <div class="banner-text text-center">
                    <div class="container">
                        <!-- Section Title Starts -->
                        <div class="row text-center">
                            <div class="col-xs-12">
                                <!-- Title Starts -->
                                <h2 class="title-head">Liquidate<span> Dashboard</span></h2>
                                <!-- Title Ends -->
                                <hr>                                
                                <!-- Breadcrumb Ends -->
                            </div>
                        </div>
                        <!-- Section Title Ends -->
                    </div>
                </div>
            </div>
        </section>        
        <!-- Section Shopping Cart Starts -->
        <section class="shop-cart">
            <!--Start section-->
            <div class="container">                
                <div class="row">
					<!-- Purchased Products Starts -->
                        <center><h2 class="title-head"style="font-size: 20px;">Auction Bids</h2></center>
                    <div class="col-xs-12 table-responsive">
                        <table class="table order text-center">
                            <colgroup>
                                <col class="col-xs-1">
                                <col class="col-xs-2 col-sm-5">
                                <col class="col-xs-2">
                                <col class="col-xs-1 col-sm-2">
                                <col class="col-xs-2 col-sm-2">
                            </colgroup>
                            <thead>
                                <tr>  
                                    <th></th>                                  
                                    <th>School</th>
                                    <th>Liquid Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    session_start();
                                    
                                    $host="localhost";
                                    $user="boscofes_bemp";
                                    $pass="FatherJohnBoscoBoscoFest2018";
                                    $db="boscofes_bemp";
                                    
                                    mysql_connect($host,$user,$pass);
                                    mysql_select_db($db);
                                    
                                    $longName= array("Lakshmipat Singhania Academy","Loreto House","Don Bosco Liluah","Modern High School For Girls","St.Josephs Convent","St.James School","Mahadevi Birla World Academy","La Martiniere For Boys","St.Xaviers Collegiate School","Don Bosco Park Circus","Delhi Public School Mega City");
                                    $shortName= array("lsa","lh","dbl","mhs","sjc","james","mbwa","lmb","sxcs","dbpc","dps");
                                    
                                    
                                    global $arr;
                                    $_SESSION['count']++;
                                    $arr=array();
                                    
                                    for($i=0;$i<count($longName);$i++){
                                        $total=0;
                                        $sql="SELECT balance FROM bank_balance WHERE schoolname='".$longName[$i]."' LIMIT 1";
                                        $res=mysql_query($sql);
                                        $row=mysql_fetch_row($res);
                                        $total=$row[0];
                                        
                                        for($j=0;$j<count($longName);$j++){
                                            $sql="SELECT * FROM share_prices WHERE schoolname='".$longName[$j]."' LIMIT 1";
                                            $res=mysql_query($sql);
                                            $row=mysql_fetch_row($res);
                                            $price=$row[4];
                                            
                                            $sql="SELECT $shortName[$j] FROM holdings WHERE schoolname='".$longName[$i]."' LIMIT 1";
                                            $res=mysql_query($sql);
                                            $row=mysql_fetch_row($res);
                                            $holding=$row[0];
                                            
                                            $total=$total +($holding*$price);
                                            
                                            //$time=time();
  
                                        }
                                        
                                        $time=time();
                                        
                                        $sql = "SELECT * FROM fixed_deposit WHERE schoolname='".$longName[$i]."' ";
                                        
                                        $result=mysql_query($sql);
                                        $row=mysql_fetch_array($result);
                                        $currentAmount=$row['amount'];
                                        $currentTime = $row['timestamp'];
                                        $currentInterest=$row['interest'];
                                        
                                        if($currentTime==NULL)
                                            $timeOfInterest=0;
                                        else
                                            $timeOfInterest=$time-$currentTime;
                                        
                                        $newInterest = $currentInterest+ ($timeOfInterest * 0.03/3600 * $currentAmount);
                                        
                                        $total = $total + $currentAmount + $newInterest;
                                        
                                        echo "<tr><td></td><td class=\"text-left\"><h6 class=\"product\">" . $longName[$i]. "</h6></td><td class=\"text-left\"><h6 class=\"product\">" . ($total) . "</h6></td></tr>";
                                    }
                                    /**
                                    for($i=0;$i<count($longName);$i++){
                                        $sql= "SELECT * FROM share_prices WHERE schoolname='".$longName[$i]."' LIMIT 1";
                                        $result = mysql_query($sql);
                                        $row = mysql_fetch_row($result);
                                        $price= $row[4];
                                        echo $price;
                                        $sql2= "SELECT * FROM holdings WHERE schoolname='".$longName[$i]."' LIMIT 1";
                                        $res = mysql_query($sql2);
                                        $row2 = mysql_fetch_row($res);
                                        $num = $row2['($i+2)'];
                                        echo "<tr><td></td><td class=\"text-left\"><h6 class=\"product\">" . $longName[$i]. "</h6></td><td class=\"text-left\"><h6 class=\"product\">" . ($price) . "</h6></td></tr>";
                                        $arr[$i]=($price * $num);
                                    }**/
                                    
                                    ?>
                            </tbody>
                        </table>                        
                    </div>
					<!-- Purchased Products Ends -->
					<!-- Cart Totals Ends -->
                </div>
            </div>
        </section>
		<!-- Section Shopping Cart Ends -->
        <!-- Footer Starts -->
        <footer class="footer">            
            <!-- Footer Top Area Ends -->
            <!-- Footer Bottom Area Starts -->
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Copyright Text Starts -->
                            <p class="text-center">Copyright © 2018 Don Bosco School Park Circus</p>
                            <!-- Copyright Text Ends -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area Ends -->
        </footer>
        <!-- Footer Ends -->
        <!-- Back To Top Starts  -->
        <a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up"></a>
        <!-- Back To Top Ends  -->

        <!-- Template JS Files -->
        <script src="http://boscoempresarios2018.com/js/jquery-2.2.4.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/bootstrap.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/select2.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/jquery.magnific-popup.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/custom.js"></script>

        <!-- Live Style Switcher JS File - only demo -->
        <script src="http://boscoempresarios2018.com/js/styleswitcher.js"></script>

    </div>
    <!-- Wrapper Ends -->
</body>


<!-- Mirrored from slimhamdi.net/bayya/shopping-cart.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 27 Oct 2018 07:18:50 GMT -->
</html>
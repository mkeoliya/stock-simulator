<?php
session_start();
/**
if (!isset($_SESSION['username'])) {
  session_start();
  session_destroy();
  header('Location:index-2.php');
  exit();
}**/
if(!isset($_SESSION['adminValid'])){
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>Stock Transactions</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="http://boscoempresarios2018.com/images/favicon.png">

    <!-- Template CSS Files -->
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/magnific-popup.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/select2.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/style.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/skins/orange.css">

    <!-- Live Style Switcher - demo only -->
    <link rel="alternate stylesheet" type="text/css" title="orange" href="css/skins/orange.css" /> 

    <!-- Template JS Files -->
    <script src="js/modernizr.js"></script>

</head>

<body>
    <!-- Wrapper Starts -->
    <div class="wrapper">
        <!-- Header Starts -->
        <header class="header">
            <div class="container">
                <div class="row">
                    <!-- Logo Starts -->
                    <div class="main-logo col-xs-12 col-md-3 col-md-2 col-lg-2 hidden-xs">
                        <a href="index.php">
                            <img id="logo" class="img-responsive" src="http://boscoempresarios2018.com/images/logo-dark.png" alt="logo">
                        </a>
                    </div>
                    <!-- Logo Ends -->
                    <!-- Statistics Starts -->
                    <div class="col-md-7 col-lg-7">
                        <marquee><ul class="unstyled bitcoin-stats text-center">

                            <?php
                                $host="localhost";
                                $user="boscofes_bemp";
                                $pass="FatherJohnBoscoBoscoFest2018";
                                $db="boscofes_bemp";

                                 $con=mysqli_connect($host,$user,$pass,$db);
                                 if (mysqli_connect_errno())
                                 {
                                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                 }                                 
                                 $sql= "SELECT * FROM share_prices";
                                 $result=mysqli_query($con,$sql);
                                 while($row = mysqli_fetch_array($result)){
                                    if($row['curr_price']>$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-up\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else if($row['curr_price']<$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-down\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-no-change\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                }
                                  

                            ?>
                        </ul></marquee>
                    </div>
                    <!-- Statistics Ends -->
                    <!-- User Sign In/Sign Up Starts -->
                    <div class="col-md-3 col-lg-3">
                        <ul class="unstyled user">
                            <li class="sign-in"><a href="shares.php" class="btn btn-primary">Stock Exchange</a></li>
                        </ul>
                    </div>
                    <!-- User Sign In/Sign Up Ends -->
                </div>
            </div>
        </header>
        <!-- Header Ends -->
        <!-- Banner Area Starts -->
        <section class="banner-area">
            <div class="banner-overlay">
                <div class="banner-text text-center">
                    <div class="container">
                        <!-- Section Title Starts -->
                        <div class="row text-center">
                            <div class="col-xs-12">
                                <!-- Title Starts -->
                                <h2 class="title-head">Admin's<span> Dashboard</span></h2>
                                <!-- Title Ends -->
                                <hr>                                
                                <!-- Breadcrumb Ends -->
                            </div>
                        </div>
                        <!-- Section Title Ends -->
                    </div>
                </div>
            </div>
        </section>        
        <!-- Section Shopping Cart Starts -->
        <section class="shop-cart">
            <!--Start section-->
            <div class="container">                
                <div class="row">
					<!-- Purchased Products Starts -->
                    <center><a href="home.php"><button class="btn btn-primary" name="dash" type="button">Home</button></a>
                    
                        <br><h2 class="title-head"style="font-size: 20px;">Stock Transactions</h2></center>
                    <div class="col-xs-12 table-responsive">
                        <table class="table order text-center">
                            <thead>
                                <tr>                                 
                                    <th class="text-center">School Name</th>
                                    <th class="text-center">Transaction Type</th>
                                    <th class="text-center">Share Name</th>
                                    <th class="text-center">Share Price</th>
                                    <th class="text-center">Share Amount</th>
                                    <th class="text-center">Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $host="localhost";
                                $user="boscofes_bemp";
                                $pass="FatherJohnBoscoBoscoFest2018";
                                $db="boscofes_bemp";

                                 $con=mysqli_connect($host,$user,$pass,$db);
                                 if (mysqli_connect_errno())
                                 {
                                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                 }                                 

                                 $long=array("Lakshmipat Singhania Academy","Loreto House","Don Bosco Liluah","Modern High School For Girls","St.Josephs Convent","St.James School","Mahadevi Birla World Academy","La Martiniere For Boys","St.Xaviers Collegiate School","Don Bosco Park Circus","Delhi Public School Mega City");
                                 $sql= "SELECT * FROM transaction_record ORDER BY id DESC";
                                 $result=mysqli_query($con,$sql);
                                 while($row = mysqli_fetch_array($result)){
                                   echo "<tr><td><h6 class=\"product\">" . $row['schoolname']. "</h6></td><td><h6 class=\"product\">" . $row['transaction_type'] . "</h6></td><td><h6 class=\"product\">" . $row['share_name'] . "</h6></td><td><h6 class=\"product\">" . $row['share_price'] . "</h6></td><td><h6 class=\"product\">" . $row['share_amount'] . "</h6></td><td><h6 class=\"product\">" . $row['timestamp'] . "</h6></td></tr>";
                                }
                            ?> 
                            </tbody>
                        </table>                        
                    </div>
                </div>
            </div>
        </section>
		<!-- Section Shopping Cart Ends -->
        <!-- Footer Starts -->
        <footer class="footer">            
            <!-- Footer Top Area Ends -->
            <!-- Footer Bottom Area Starts -->
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Copyright Text Starts -->
                            <p class="text-center">Copyright © 2018 Don Bosco School Park Circus</p>
                            <!-- Copyright Text Ends -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area Ends -->
        </footer>
        <!-- Footer Ends -->
        <!-- Back To Top Starts  -->
        <a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up"></a>
        <!-- Back To Top Ends  -->

        <!-- Template JS Files -->
        <script src="http://boscoempresarios2018.com/js/jquery-2.2.4.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/bootstrap.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/select2.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/jquery.magnific-popup.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/custom.js"></script>

        <!-- Live Style Switcher JS File - only demo -->
        <script src="http://boscoempresarios2018.com/js/styleswitcher.js"></script>

    </div>
    <!-- Wrapper Ends -->
</body>


<!-- Mirrored from slimhamdi.net/bayya/shopping-cart.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 27 Oct 2018 07:18:50 GMT -->
</html>
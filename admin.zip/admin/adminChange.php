<?php
session_start();
date_default_timezone_set("Asia/Calcutta");
global $date;
$date=date('d-m-Y H:i:s a');


/**
if (!isset($_SESSION['username'])) {
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}
**/

if(!isset($_SESSION['adminValid'])){
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}

$host="localhost";
$user="boscofes_bemp";
$pass="FatherJohnBoscoBoscoFest2018";
$db="boscofes_bemp";

mysql_connect($host,$user,$pass);
mysql_select_db($db);

if(isset($_POST['submit'])){
  $event_name = $_POST['event_name'];
  //if($event_name!="select")
  //{

      $sql = "UPDATE share_prices SET $event_name='0'";
      $result=mysql_query($sql);
    
      $schoolPoints= array($_POST['lsa'],$_POST['lh'],$_POST['dbl'],$_POST['mhs'],$_POST['sjc'],$_POST['james'],$_POST['mbwa'],$_POST['lmb'],$_POST['sxcs'],$_POST['dbpc'],$_POST['dps']);
      $longName= array("Lakshmipat Singhania Academy","Loreto House","Don Bosco Liluah","Modern High School For Girls","St.Josephs Convent","St.James School","Mahadevi Birla World Academy","La Martiniere For Boys","St.Xaviers Collegiate School","Don Bosco Park Circus","Delhi Public School Mega City");
      for($i=0;$i<count($schoolPoints);$i++){
        update($longName[$i],$schoolPoints[$i],$event_name,$date);
      }
  //}
  //else
  //{
  //    echo "<script>alert('Please select a valid event');</script>";
  //}
}

function update($schoolname, $pt,$event_name,$date)
{
   
  //$sql = "SELECT base_price FROM share_prices WHERE schoolname = '$schoolname'";
  $sql = "SELECT * FROM share_prices WHERE schoolname = '$schoolname'";
  $res = mysql_query($sql);
  $row = mysql_fetch_row($res);
  $currentBase=$row[2];

  $curr_price = $row[4];

  //$sql = "UPDATE share_prices SET prev_price = '$curr_price' WHERE schoolname = '$schoolname'";
  //$res = mysql_query($sql);

  $currentBase = $currentBase + $pt;

  $sql = "UPDATE share_prices SET base_price = '$currentBase' WHERE schoolname = '$schoolname'";
  $res = mysql_query($sql);

  $sql = "SELECT * FROM share_prices WHERE schoolname = '$schoolname'";
  $res = mysql_query($sql);
  $row = mysql_fetch_row($res);
   $price = $row[2] + $row[5] + $row[6] + $row[7] + $row[8] + $row[9]+ $row[10]+ $row[11]+ $row[12]+ $row[13]+ $row[14]+ $row[15]+ $row[16];

  $sql = "UPDATE share_prices SET prev_price = '".$curr_price."', curr_price = '".$price."' WHERE schoolname = '$schoolname'";
  $res = mysql_query($sql);
  
  $table = getShortTrade($schoolname);
  
  $sql = "INSERT INTO $table (price, time) VALUES ('$price','$date')";
  $res = mysql_query($sql);
  
$sql = "INSERT INTO admin_record (event_name, schoolname, shareChange, time) VALUES ('$event_name', '$schoolname', '$pt', '$date')";
$result=mysql_query($sql);
}

function getShortTrade($schoolTrade){
$longName= array("Lakshmipat Singhania Academy","Loreto House","Don Bosco Liluah","Modern High School For Girls","St.Josephs Convent","St.James School","Mahadevi Birla World Academy","La Martiniere For Boys","St.Xaviers Collegiate School","Don Bosco Park Circus","Delhi Public School Mega City");
$shortName = array("lsa","lh","dbl","mhs","sjc","james","mbwa","lmb","sxcs","dbpc","dps");
    for($i=0;$i<count($longName);$i++){
      if(strcmp($longName[$i],$schoolTrade)==0)
             return $shortName[$i];
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>Bosco Empresarios 2018</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="http://boscoempresarios2018.com/images/favicon.png">

    <!-- Template CSS Files -->
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/magnific-popup.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/select2.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/style.css">
	<link rel="stylesheet" href="http://boscoempresarios2018.com/css/skins/orange.css">
	
	<!-- Live Style Switcher - demo only -->
    <link rel="alternate stylesheet" type="text/css" title="orange" href="http://boscoempresarios2018.com/css/skins/orange.css" /> 

    <!-- Template JS Files -->
    <script src="http://boscoempresarios2018.com/js/modernizr.js"></script>

    <script type="text/javascript">
        function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
    </script>


    <style>      
      .chart-container {
        width: 90%;
        height: auto;        
      }
      @media (max-width: 576px) {
      .chart-container {
          width: 95%;
          height: auto;
        }
      }
      #more {display: none;}
    </style>

</head>

<body>
    <!-- Wrapper Starts -->
    <div class="wrapper">
        <!-- Header Starts -->
        <header class="header">
            <div class="container">
                <div class="row">
                    <!-- Logo Starts -->
                    <div class="main-logo col-xs-12 col-md-3 col-md-2 col-lg-2 hidden-xs">
                        <a href="index.php">
                            <img id="logo" class="img-responsive" src="http://boscoempresarios2018.com/images/logo-dark.png" alt="logo">
                        </a>
                    </div>
                    <!-- Logo Ends -->
                    <!-- Statistics Starts -->
                    <div class="col-md-7 col-lg-7">
                        <marquee><ul class="unstyled bitcoin-stats text-center">

                                 <?php
                                $host="localhost";
                                $user="boscofes_bemp";
                                $pass="FatherJohnBoscoBoscoFest2018";
                                $db="boscofes_bemp";

                                 $con=mysqli_connect($host,$user,$pass,$db);
                                 if (mysqli_connect_errno())
                                 {
                                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                 }                                 
                                 $sql= "SELECT * FROM share_prices";
                                 $result=mysqli_query($con,$sql);
                                 while($row = mysqli_fetch_array($result)){
                                    if($row['curr_price']>$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-up\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else if($row['curr_price']<$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-down\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-no-change\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                }
                                  

                            ?>
                        </ul></marquee>
                    </div>
                    <!-- Statistics Ends -->
                    <!-- User Sign In/Sign Up Starts -->
                    <div class="col-md-3 col-lg-3">
                        <ul class="unstyled user">
                            <li class="sign-in"><a href="http://boscoempresarios2018.com/shares.php" class="btn btn-primary">Stock Exchange</a></li>
                        </ul>
                    </div>
                    <!-- User Sign In/Sign Up Ends -->
                </div>
            </div>
        </header>
        <!-- Header Ends -->
        <!-- Features Section Starts -->

        <!-- Features Section Ends -->
        <!-- About Section Starts -->
        <section class="about-us">
            <div class="container">
                <!-- Section Title Ends -->
                <!-- Section Content Starts -->
                <div class="row about-content">
                    <!-- Image Starts -->
                    <div class="col-sm-12 col-md-5 col-lg-6 text-center">
                        <img id="about-us" class="img-responsive img-about-us" src="http://boscoempresarios2018.com/images/about-us.png" alt="about us">
                    </div>
                    <!-- Image Ends -->                    
                    <!-- Content Starts -->
                    <div class="col-sm-12 col-md-7 col-lg-6">                        
                    	<div class="form-container">
					<div>
						<br class="hidden-xs"><br class="hidden-xs">
						<!-- Section Title Starts -->
						<div class="row text-center">
							<h2 class="title-head">Admin <span>Portal</span></h2>
						</div>
						<!-- Section Title Ends -->
						<!-- Form Starts -->
						<form method="post" action="adminChange.php">
							<!-- Input Field Starts -->
							<div class="form-group">							
        							<select class="form-control" name="event_name">
									<option value="select">Select Event</option>
							       <option value="boulevard">Boulevard</option>
							       <option value="ballyhoo">Ballyhoo</option>
							       <option value="boardroom">Boardroom</option>
							       <option value="quidproquo">Quid Pro Quo</option>
							       <option value="bpl">Premier League</option>
							       <option value="builder">Builder</option>
							       <option value="indemnity">Indemnity</option>
							       <option value="subterfuge">Subterfuge</option>
							       <option value="lockout">Lockout</option>
							       <option value="contingency">Contingency</option>
							       <option value="linkingpin">Linking Pin</option>
							       <option value="freakonomics">Freakonomics</option>
						        </select>
							</div>
							<br>
							<center><h3 style="color:#FFF">Enter Share Price Change of Each School</h3></center><br>
							<!-- Input Field Ends -->
							<!-- Input Field Starts -->
							<div class="form-group">
								<input class="form-control" name="lsa" placeholder="Lakshmipat Singhania Academy" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="lh" placeholder="Loreto House" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="dbl" placeholder="Don Bosco Liluah" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="mhs" placeholder="Modern High School For Girls" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="sjc" placeholder="St.Josephs Convent" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="james" placeholder="St.James School" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="mbwa" placeholder="Mahadevi Birla World Academy" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="lmb" placeholder="La Martiniere For Boys" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="sxcs" placeholder="St.Xaviers Collegiate School" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="dbpc" placeholder="Don Bosco Park Circus" type="number" autocomplete="off" required>
							</div>
							
							<div class="form-group">
								<input class="form-control" name="dps" placeholder="Delhi Public School Mega City" type="number" autocomplete="off" required>
							</div>
							
							
							<!-- Input Field Ends -->
							<!-- Submit Form Button Starts -->
							<div class="form-group">
								<button class="btn btn-primary" name="submit" type="submit">Submit</button>	&nbsp;&nbsp;&nbsp;&nbsp;
								<a href="home.php"><button class="btn btn-primary" name="dash" type="button">Home</button></a>								
							</div>
							<!-- Submit Form Button Ends -->
						</form>
						<!-- Form Ends -->
					</div>      
                    </div>
                    <!-- Content Ends -->
                </div>
                <!-- Section Content Ends -->
            </div>
        </section>
        <!-- About Section Ends -->
        <!-- Footer Starts -->
        <footer class="footer">            
            <!-- Footer Top Area Ends -->
            <!-- Footer Bottom Area Starts -->
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Copyright Text Starts -->
                            <p class="text-center">Copyright © 2018 Don Bosco School Park Circus</p>
                            <!-- Copyright Text Ends -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area Ends -->
        </footer>
        <!-- Footer Ends -->
		<!-- Back To Top Starts  -->
        <a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up"></a>
		<!-- Back To Top Ends  -->
		
        <!-- Template JS Files -->
        <script src="http://boscoempresarios2018.com/js/jquery-2.2.4.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/bootstrap.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/select2.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/jquery.magnific-popup.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/custom.js"></script>
		
        <script type="text/javascript" src="http://boscoempresarios2018.com/js/jquery.min.js"></script>
        <script type="text/javascript" src="http://boscoempresarios2018.com/js/Chart.min.js"></script>

		<!-- Live Style Switcher JS File - only demo -->
		<script src="js/styleswitcher.js"></script>

    </div>
    <!-- Wrapper Ends -->
</body>

</html>
<?php
session_start();
$time=time();

if(!isset($_SESSION['adminValid'])){
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}

$host="localhost";
$user="boscofes_bemp";
$pass="FatherJohnBoscoBoscoFest2018";
$db="boscofes_bemp";

mysql_connect($host,$user,$pass);
mysql_select_db($db);

$longName= array("Lakshmipat Singhania Academy","Loreto House","Don Bosco Liluah","Modern High School For Girls","St.Josephs Convent","St.James School","Mahadevi Birla World Academy","La Martiniere For Boys","St.Xaviers Collegiate School","Don Bosco Park Circus","Delhi Public School Mega City");

for($i=0;$i<count($longName);$i++)
{
    $sql = "SELECT * FROM fixed_deposit WHERE schoolname='".$longName[$i]."' ";
    
    $result=mysql_query($sql);
    $row=mysql_fetch_array($result);
    $currentAmount=$row['amount'];
    $currentTime = $row['timestamp'];
    $currentInterest=$row['interest'];
    
    if($currentTime==NULL)
        $timeOfInterest=0;
    else
        $timeOfInterest=$time-$currentTime;
    
    $newInterest = $currentInterest+ ($timeOfInterest * 0.03/3600 * $currentAmount);
    
    $sql = "UPDATE fixed_deposit SET timestamp=NULL,interest='$newInterest' WHERE schoolname='".$longName[$i]."' ";
	$result=mysql_query($sql);
}
header('Location:home.php');
?>
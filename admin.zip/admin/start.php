<?php
session_start();
$host="localhost";
$user="boscofes_bemp";
$pass="FatherJohnBoscoBoscoFest2018";
$db="boscofes_bemp";

if(!isset($_SESSION['adminValid'])){
  session_start();
  session_destroy();
  header('Location:index.php');
  exit();
}

$time=time();

mysql_connect($host,$user,$pass);
mysql_select_db($db);

$sql = "UPDATE fixed_deposit SET timestamp='$time'";
$result = mysql_query($sql);
header('Location:home.php');
?>
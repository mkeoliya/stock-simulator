<?php
session_start();

if(!isset($_SESSION['adminValid'])){
    header('Location:index.php');
}

$host="localhost";
$user="boscofes_bemp";
$pass="FatherJohnBoscoBoscoFest2018";
$db="boscofes_bemp";
mysql_connect($host,$user,$pass);
mysql_select_db($db);
$currentschool=$_SESSION['username'];
//echo "<script>alert('Schoolname is $schoolname deposit amount is $depositAmount event_name is $event_name time is $time');</script>";

if(isset($_POST['logout'])){
  session_destroy();
  header('Location : index.php');
}


if(isset($_POST['submit'])){
	$depositAmount=$_POST['depositAmount'];
	$time=time();
  
    $sql = "SELECT * FROM fixed_deposit WHERE schoolname='".$currentschool."' ";
    $result=mysql_query($sql);
    $row=mysql_fetch_array($result);
    $currentAmount=$row['amount'];
    $currentTime = $row['timestamp'];
    $currentInterest=$row['interest'];
   
   if($currentTime==NULL)
       $timeOfInterest=0;
    else
       $timeOfInterest=$time-$currentTime;
       $newInterest= $currentInterest+ ($timeOfInterest * 0.03/3600 * $currentAmount);
   
    $newAmount = $currentAmount + $depositAmount;
    if($newAmount>500000)
      echo "<script>alert('Cannot invest more than Rs.5 lakhs in fixed deposit');</script>";
    else{
    
    $sql="SELECT balance FROM bank_balance WHERE schoolname='".$currentschool."' ";
    $res=mysql_query($sql);
    $row=mysql_fetch_array($res);
    $currBal=$row[0];
    //echo "<script>alert('Current balance is = $currBal');</script>";
    
    if($currBal>=$depositAmount){
       $newBal=$currBal-$depositAmount;

	$sql = "UPDATE fixed_deposit SET amount='$newAmount', timestamp='$time',interest='$newInterest' WHERE schoolname='".$currentschool."' ";
	$result=mysql_query($sql);
	
	$sql = "UPDATE bank_balance SET balance='$newBal'  WHERE schoolname='".$currentschool."' ";
	$result=mysql_query($sql);
	
	      echo "<script>alert('You have successfully invested in the fixed deposit, New balance is $newBal');</script>";
   }
    
  else{
    echo "<script>alert('Not enough balance');</script>";
  }
 }
}
    


?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>Bosco Empresarios 2018</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="http://boscoempresarios2018.com/images/favicon.png">

    <!-- Template CSS Files -->
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/magnific-popup.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/select2.min.css">
    <link rel="stylesheet" href="http://boscoempresarios2018.com/css/style.css">
	<link rel="stylesheet" href="http://boscoempresarios2018.com/css/skins/orange.css">
	
	<!-- Live Style Switcher - demo only -->
    <link rel="alternate stylesheet" type="text/css" title="orange" href="http://boscoempresarios2018.com/css/skins/orange.css" /> 

    <!-- Template JS Files -->
    <script src="http://boscoempresarios2018.com/js/modernizr.js"></script>

    <script type="text/javascript">
        function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
    </script>


    <style>      
      .chart-container {
        width: 90%;
        height: auto;        
      }
      @media (max-width: 576px) {
      .chart-container {
          width: 95%;
          height: auto;
        }
      }
      #more {display: none;}
    </style>

</head>

<body>
    

    
    <!-- Wrapper Starts -->
    <div class="wrapper">
        <!-- Header Starts -->
        <header class="header">
            <div class="container">
                <div class="row">
                    <!-- Logo Starts -->
                    <div class="main-logo col-xs-12 col-md-3 col-md-2 col-lg-2 hidden-xs">
                        <a href="index.php">
                            <img id="logo" class="img-responsive" src="http://boscoempresarios2018.com/images/logo-dark.png" alt="logo">
                        </a>
                    </div>
                    <!-- Logo Ends -->
                    <!-- Statistics Starts -->
                    <div class="col-md-7 col-lg-7">
                        <marquee><ul class="unstyled bitcoin-stats text-center">

                                 <?php
                                $host="localhost";
                                $user="boscofes_bemp";
                                $pass="FatherJohnBoscoBoscoFest2018";
                                $db="boscofes_bemp";

                                 $con=mysqli_connect($host,$user,$pass,$db);
                                 if (mysqli_connect_errno())
                                 {
                                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                                 }                                 
                                 $sql= "SELECT * FROM share_prices";
                                 $result=mysqli_query($con,$sql);
                                 while($row = mysqli_fetch_array($result)){
                                    if($row['curr_price']>$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-up\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else if($row['curr_price']<$row['prev_price'])
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-down\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                    else
                                        echo "<li><h6 style=\"display: inline-block;\">" . $row['curr_price'] . "</h6><div style=\"display: inline-block; margin-left: 5px\" class=\"arrow-no-change\"></div><div><span>" . $row['schoolname'] . "</span></div></li>";
                                }
                                  

                            ?>
                        </ul></marquee>
                    </div>
                    <!-- Statistics Ends -->
                    <!-- User Sign In/Sign Up Starts -->
                    <div class="col-md-3 col-lg-3">
                        <ul class="unstyled user">
                            <li class="sign-in"><a href="http://boscoempresarios2018.com/shares.php" class="btn btn-primary">Stock Exchange</a></li>
                        </ul>
                    </div>
                    <!-- User Sign In/Sign Up Ends -->
                </div>
            </div>
        </header>
        <!-- Header Ends -->
        <!-- Features Section Starts -->

        <!-- Features Section Ends -->
        <!-- About Section Starts -->
        <section class="about-us">
            <div class="container">
                <!-- Section Title Ends -->
                <!-- Section Content Starts -->
                <div class="row about-content">
                    <!-- Image Starts -->
                    <div class="col-sm-12 col-md-5 col-lg-6 text-center">
                        <img id="about-us" class="img-responsive img-about-us" src="http://boscoempresarios2018.com/images/about-us.png" alt="about us">
                    </div>
                    <!-- Image Ends -->                    
                    <!-- Content Starts -->
                    <div class="col-sm-12 col-md-7 col-lg-6">                        
                    	<div class="form-container">
					<div>
						<br class="hidden-xs"><br class="hidden-xs">
						<!-- Section Title Starts -->
						<div class="row text-center">
							<h2 class="title-head">Bosco Stock <span>Exchange</span></h2>
						</div>
						<!-- Section Title Ends -->
						<!-- Form Starts -->
						<form method="post" action="fixed_deposit.php">
							<!-- Input Field Starts -->
							<div class="form-group">
							    
							    
							    
							<div class="form-group">
								<input class="form-control" name="depositAmount" type="number"  min="1" autocomplete="off" placeholder="Enter Deposit Amount" required>
							</div>
							<!-- Input Field Ends -->
							<!-- Submit Form Button Starts -->
							<div class="form-group">
								<button class="btn btn-primary" name="submit" type="submit">Submit</button>	&nbsp;&nbsp;&nbsp;&nbsp;
								<a href="dashboard.php"><button class="btn btn-primary" name="dash" type="button">Back To Dashboard</button></a>
							</div
							
							<!-- Submit Form Button Ends -->
						</form>
						
						<!-- Form Ends -->
					</div>      
                    </div>
                    <!-- Content Ends -->
                </div>
                <!-- Section Content Ends -->
            </div>
        </section>
        <!-- About Section Ends -->
        <!-- Footer Starts -->
        <footer class="footer">            
            <!-- Footer Top Area Ends -->
            <!-- Footer Bottom Area Starts -->
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Copyright Text Starts -->
                            <p class="text-center">Copyright © 2018 Don Bosco School Park Circus</p>
                            <!-- Copyright Text Ends -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area Ends -->
        </footer>
        <!-- Footer Ends -->
		<!-- Back To Top Starts  -->
        <a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up"></a>
		<!-- Back To Top Ends  -->
		
        <!-- Template JS Files -->
        <script src="http://boscoempresarios2018.com/js/jquery-2.2.4.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/bootstrap.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/select2.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/jquery.magnific-popup.min.js"></script>
        <script src="http://boscoempresarios2018.com/js/custom.js"></script>
		
        <script type="text/javascript" src="http://boscoempresarios2018.com/js/jquery.min.js"></script>
        <script type="text/javascript" src="http://boscoempresarios2018.com/js/Chart.min.js"></script>

		<!-- Live Style Switcher JS File - only demo -->
		<script src="js/styleswitcher.js"></script>

    </div>
    <!-- Wrapper Ends -->
</body>

</html>
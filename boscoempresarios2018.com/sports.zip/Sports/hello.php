<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Points saved</title>
<link href="css/index.css" rel="stylesheet" type="text/css">
    <link href="css/style2.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header1.php");
include("header.php");
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<font size="+5">Points have been successfull tabulated! Redirecting to home.</font>
<?php

header('Refresh: 2; URL=index.php');
?>
</body>
</html>
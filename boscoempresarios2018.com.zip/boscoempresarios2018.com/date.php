<?php
date_default_timezone_set("Asia/Calcutta");
$date=date('d-m-Y H:i:s a');
echo $date;
?>
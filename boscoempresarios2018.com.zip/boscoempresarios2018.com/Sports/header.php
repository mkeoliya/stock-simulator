<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/index.css" rel="stylesheet" type="text/css">
    <link href="css/style2.css" rel="stylesheet" type="text/css">
    <style type="text/css">
    body,td,th {
	color: #F5F5F5;
}
    </style>
</head>

<body>
<font size="+5">D. B. P. C. Sports Management System</font>
</body>
</html>
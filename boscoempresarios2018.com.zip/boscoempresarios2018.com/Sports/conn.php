<?php
$con = mysqli_connect('localhost', 'boscofes_bemp', 'FatherJohnBoscoBoscoFest2018','boscofes_sports');
?>